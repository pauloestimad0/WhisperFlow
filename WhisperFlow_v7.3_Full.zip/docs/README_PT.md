# WhisperFlow v7.3
**Autor:** Paulo Estimado  
**Licença:** MIT  
**Linguagem:** PowerShell + Python 3.12  
**Plataforma:** Windows 10/11  

WhisperFlow é um assistente de ditado por voz otimizado com o modelo Whisper da OpenAI.  
Permite transcrever automaticamente o que é falado em qualquer campo de texto, usando GPU CUDA (quando disponível) ou CPU como alternativa.

## 🧠 Recursos
- Hotkey global (Ctrl+Alt+J)
- Gravação automática de áudio
- Transcrição instantânea com Whisper
- Colagem do texto no campo ativo
- Instalação automática via PowerShell
- Log completo e suporte a GPU

## 🧰 Instalação
1. Execute install_whisperflow_v7.3.ps1 como Administrador  
2. O instalador configurará Python 3.12, criará o ambiente virtual e instalará dependências  
3. Um atalho será criado na área de trabalho  
4. Pressione **Ctrl+Alt+J** para começar a ditar

## ✨ Créditos
Desenvolvido por **Paulo Estimado** — Outubro de 2025.
