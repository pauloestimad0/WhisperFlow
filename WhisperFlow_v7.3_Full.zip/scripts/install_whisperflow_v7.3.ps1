Write-Host "Instalando WhisperFlow v7.3..." -ForegroundColor Cyan
$PythonUrl = "https://www.python.org/ftp/python/3.12.3/python-3.12.3-amd64.exe"
$PythonPath = "C:\Program Files\Python312"
$BasePath = "C:\Temp\WhisperFlow"

if (!(Test-Path $BasePath)) { New-Item -ItemType Directory -Force -Path $BasePath | Out-Null }
if (!(Test-Path "$PythonPath\python.exe")) {
    Invoke-WebRequest -Uri $PythonUrl -OutFile "$BasePath\python-installer.exe"
    Start-Process "$BasePath\python-installer.exe" -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1" -Wait
}
$env:Path += ";$PythonPath;$PythonPath\Scripts"

python -m venv "$BasePath\venv"
& "$BasePath\venv\Scripts\pip.exe" install --upgrade pip setuptools wheel
& "$BasePath\venv\Scripts\pip.exe" install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
& "$BasePath\venv\Scripts\pip.exe" install faster-whisper keyboard sounddevice numpy pyperclip soundfile pyaudio
Write-Host "WhisperFlow instalado com sucesso!" -ForegroundColor Green
