# Changelog - WhisperFlow v7.3
- Added support for Python 3.12 (PyTorch compatible)
- Improved installation and logging
- Added bilingual documentation (PT/EN)
- Automatic shortcut creation
- GPU + CPU fallback ready
